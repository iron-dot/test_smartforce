from flask import Flask, request, jsonify, session, render_template
from flask_sqlalchemy import SQLAlchemy
from werkzeug.security import generate_password_hash, check_password_hash
import gradio as gr
import os
import random
import string

import os

app = Flask(__name__, template_folder=os.path.join(os.path.dirname(__file__), 'templates'))

app.config['SECRET_KEY'] = os.urandom(24)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///smartforce.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
db = SQLAlchemy(app)

# 데이터베이스 모델 설정
class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(150), nullable=False, unique=True)
    email = db.Column(db.String(150), nullable=False, unique=True)
    phone = db.Column(db.String(50), nullable=False)
    password = db.Column(db.String(200), nullable=False)
    consent_given = db.Column(db.Boolean, default=False)
    is_admin = db.Column(db.Boolean, default=False)

class Coupon(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    code = db.Column(db.String(50), unique=True, nullable=False)
    discount_amount = db.Column(db.Float, nullable=False)
    is_used = db.Column(db.Boolean, default=False)

# 무작위 쿠폰 코드 생성 함수
def generate_random_code(length=8):
    return ''.join(random.choices(string.ascii_uppercase + string.digits, k=length))

# 특별 쿠폰과 일반 쿠폰 생성 함수
def create_coupons():
    for _ in range(10):
        code = generate_random_code()
        coupon = Coupon(code=code, discount_amount=2000)
        db.session.add(coupon)
    for _ in range(90):
        code = generate_random_code()
        coupon = Coupon(code=code, discount_amount=1000)
        db.session.add(coupon)
    db.session.commit()

# Flask API 정의
@app.route('/register', methods=['POST'])
def register():
    data = request.json
    username = data.get("username")
    email = data.get("email")
    phone = data.get("phone")
    password = data.get("password")
    consent = data.get("consent")

    if User.query.filter_by(email=email).first():
        return jsonify({"message": "이미 사용 중인 이메일입니다."}), 400

    if not consent:
        return jsonify({"message": "개인정보 수집 및 이용에 동의해야 합니다."}), 400

    hashed_password = generate_password_hash(password)
    new_user = User(username=username, email=email, phone=phone, password=hashed_password, consent_given=consent)
    db.session.add(new_user)
    db.session.commit()
    return jsonify({"message": "회원가입이 완료되었습니다."}), 201

@app.route('/login', methods=['POST'])
def login():
    data = request.json
    email = data.get("email")
    password = data.get("password")

    user = User.query.filter_by(email=email).first()
    if user and check_password_hash(user.password, password):
        session['user_id'] = user.id
        session['is_admin'] = user.is_admin
        return jsonify({"message": "로그인 성공!"}), 200
    else:
        return jsonify({"message": "로그인 실패."}), 400

@app.route('/apply_coupon', methods=['POST'])
def apply_coupon():
    data = request.json
    code = data.get("coupon_code")

    coupon = Coupon.query.filter_by(code=code, is_used=False).first()
    if coupon:
        coupon.is_used = True
        db.session.commit()
        return jsonify({"message": f"{coupon.discount_amount} 포인트가 적립되었습니다!"}), 200
    else:
        return jsonify({"message": "유효하지 않은 쿠폰 코드입니다."}), 400

# HTML 템플릿 렌더링
@app.route('/')
def home():
    return render_template('index.html')  # 홈 페이지 (예: index.html)

@app.route('/dashboard')
def dashboard():
    return render_template('dashboard.html')  # 대시보드 페이지 (예: dashboard.html)

@app.route('/admin_dashboard')
def admin_dashboard():
    return render_template('admin_dashboard.html')  # 관리자 대시보드 페이지 (예: admin_dashboard.html)

# Gradio 인터페이스 설정 함수
def gradio_interface():
    # Gradio UI와 Flask API 통합
    def register_user(username, email, phone, password, consent):
        response = app.test_client().post('/register', json={
            "username": username,
            "email": email,
            "phone": phone,
            "password": password,
            "consent": consent
        })
        return response.json["message"]

    def login_user(email, password):
        response = app.test_client().post('/login', json={
            "email": email,
            "password": password
        })
        return response.json["message"]

    def apply_coupon_code(coupon_code):
        response = app.test_client().post('/apply_coupon', json={
            "coupon_code": coupon_code
        })
        return response.json["message"]

    # Gradio 인터페이스 정의
    with app.app_context():
        interface = gr.Interface(
            fn=lambda operation, username, email, phone, password, consent, coupon_code: {
                "register_user": lambda: register_user(username, email, phone, password, consent),
                "login_user": lambda: login_user(email, password),
                "apply_coupon_code": lambda: apply_coupon_code(coupon_code)
            }[operation](),  # 선택된 operation에 따라 올바른 인자만 전달
            inputs=[
                gr.components.Radio(['register_user', 'login_user', 'apply_coupon_code'], label="Operation"),
                gr.components.Textbox(label="Username (For Register)", placeholder="Enter username"),
                gr.components.Textbox(label="Email", placeholder="Enter email"),
                gr.components.Textbox(label="Phone (For Register)", placeholder="Enter phone number"),
                gr.components.Textbox(label="Password", type="password", placeholder="Enter password"),
                gr.components.Checkbox(label="Consent to Data Collection (For Register)"),
                gr.components.Textbox(label="Coupon Code (For Apply Coupon)", placeholder="Enter coupon code")
            ],
            outputs="text",
            live=True,
            title="SmartForce Platform"
        )

        # 외부 접속을 허용하기 위해 `share=True` 옵션을 추가합니다
        interface.launch(share=True)

if __name__ == '__main__':
    # 데이터베이스 생성 및 초기화
    with app.app_context():
        db.create_all()

        # 관리자 계정 및 쿠폰 생성
        if not User.query.filter_by(email="ruin1234@gmail.com").first():
            admin = User(
                username="Ruin",
                email="ruin1234@gmail.com",
                phone="06256748964",
                password=generate_password_hash("superintelligence"),
                consent_given=True,
                is_admin=True
            )
            db.session.add(admin)
            db.session.commit()

        if Coupon.query.count() == 0:
            create_coupons()

    # Gradio 인터페이스 실행
    gradio_interface()
